// Shopkit JS
console.log('Shopkit loaded');