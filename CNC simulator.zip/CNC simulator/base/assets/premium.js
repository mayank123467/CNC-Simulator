// Premium JS
console.log('Premium loaded');